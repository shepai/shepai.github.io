"""
    Artificial 'Neural network' code
    Code By D R Shepherd, aged 18

    An abstract model of an artificial neural network. Finds correlations in string data
"""
import os
class Neuron:
    #neuron class olds the information about an item and where it leads to
    #it also holds the weights of its connections
    def __init__(n,filepath,name):
        n.path=filepath
        n.name=name
        filename=n.path+n.name+".txt"
        try: #check file exists
            file=open(filename,"r")
            file.close()
        except:
            file=open(filename,"w") #create file
            file.close()
    def addPathway(n,neuron):
        #add a pathway to the next neuron
        file=open(n.path+n.name+".txt","r")
        r=file.read()
        file.close()
        if neuron.path+neuron.name not in r: #add if not inside
            file=open(n.path+n.name+".txt","a")
            file.write(neuron.path+neuron.name+"=0.5,") #set initial weight to 0.5
            file.close()
        #otherwise the connection is more significant
    def getConnections(n):
        #get the connections in a 2 array [link,weight]
        file=open(n.path+n.name+".txt","r")
        r=file.read()
        file.close()
        r=r.split(",")[:-1] #remove last empty array and split to links
        con=[]
        for i in range(len(r)):
            item=r[i].split("=")
            con.append([item[0],(item[1])])
        return con
    def updateConnections(n,data):
        #rewrite all the connections with the new updated weights
        file=open(n.path+n.name+".txt","w")
        for i in range(len(data)):
            file.write(data[i][0]+"="+data[i][1]+",") #set initial weight to 0.5
        file.close()
class CellBody:
    #CellBody class binds the neurons and areas together to create a neural network
    #Binds information together
    def __init__(brain,filepath):
        brain.path=filepath
        #set up pathway
        sysPath=filepath+"Hidden/Output"
        if not(os.path.isdir(sysPath)):  #make a pathway
            paths=sysPath.split("/")
            file_exists=""
            for i in range(len(paths)): #loop through creating the folders specified
                try:
                    os.mkdir(file_exists+paths[i])
                    file_exists+=paths[i]+"/"
                except:
                    file_exists+=paths[i]+"/"
    def trainData(brain,data,hiddenLayer,outcome):
        #this takes in the data entered by the user and trains it to reach the outcome
        #enter array of stimulus
        output=brain.interact(data,hiddenLayer)
        hidden=[]
        for j in range(len(hiddenLayer)): #create a list of neurons
            hidden.append(Neuron(brain.path+"Hidden/",hiddenLayer[j]))
        brain.setOutput(hiddenLayer,outcome) #set the output
        if output!=None and len(output)>0:
            if outcome == output:
                print("correct")
                return True #all items correct
            else:
               
                brain.backPropogation(hidden,outcome) #update strengths
                brain.trainData(data,hiddenLayer,outcome) #train till correct
    def backPropogation(brain,hidden,outcome):
        #back propogation of the problem will find the error and change weight values
        #loop through hidden edges and find what linked to the wrong areas and decrease
        for i in range(len(hidden)):
            cons=hidden[i].getConnections()
            for j in range(len(cons)):
                    nameOf=cons[j][0].split("/")[-1]
                    if nameOf != outcome:
                        #reduce weights
                        cons[j][1]=str(round(float(cons[j][1])*0.90,4)) #decrease by 10%
                    else:
                        cons[j][1]=str(round(float(cons[j][1])*1.10,4)) #increase by 10%
            hidden[i].updateConnections(cons)
        #Vertex items which were not decreased will be increased (as they are more relevant)

    def writeData(brain,data,hidden):
        #create all the neurons in their respected layers
        #return the neuron layers to the user
        for i in range(len(data)): #loop through inpus
            neurons=(Neuron(brain.path,data[i])) #create neurons for each input
            for j in range(len(hidden)): #break up inputs into detail
                    hiddenLayer=(Neuron(brain.path+"Hidden/",hidden[j])) #create neurons for each input
                    neurons.addPathway(hiddenLayer) #connect nurons to
    def setOutput(brain,hiddenLayer,output):
        #loop through hidden layer
        #assign connection to the output
        outputNeuron=Neuron(brain.path+"Hidden/Output/",output) #convert to neuron
        for i in range(len(hiddenLayer)):
            currentNeuron=Neuron(brain.path+"Hidden/",hiddenLayer[i])
            currentNeuron.addPathway(outputNeuron)
        
    def findResponse(brain,stimuli):
        #find the most likely response in the network
        neurons=[]
        for i in range(len(stimuli)): #loop through inpus
            neurons.append(Neuron(brain.path,stimuli[i])) #create neurons for each input
        hid=brain.getConnected(neurons)
        hidden=[]
        for j in range(len(hid)):
            hidden.append(hid[j][0])
        output=brain.getConnected(hidden)
        for i in range(1,len(output)): #sort most relevant
            key=output[i][1]
            hold=output[i]
            j=i-1
            while j>=0 and key >output[j][1]:
                output[j+1]=output[j]
                j-=1
            output[j+1]=hold
        return output
    def getConnected(brain,neurons):
        cons=[]
        found=[]
        for i in range(len(neurons)): #loop through
            connections = neurons[i].getConnections() #gather the connected
            average=0
            for j in range(len(connections)): #gather average of connections
                average+=float(connections[j][1])
            if len(connections)>0:
                av=(average/len(connections))
                for j in range(len(connections)): #find connected routes
                    find=False
                    ind=0
                    try:
                        ind=f.index(connections[j][0])
                        find=True
                    except:
                        find=False
                    if float(connections[j][1])>=av and not find: #if significant
                        name=connections[j][0].split("/")[-1]
                        pathway=connections[j][0][:-len(name)]
                        cons.append([Neuron(pathway,name),av])
                        found.append(connections[j][0]+" ") #create array of used
                    elif find and float(connections[j][1])>=av: #the same item has been found again
                        cons[ind]=[cons[ind][0],cons[ind][1]*1.10] #increase by 10%
                        
        return cons
    def interact(brain,stimulus,hidden):
        #main interaction method
        #takes in the stiumuls and a length of types defining what each input is
        #the inputs are split down based on type when entered into the neural network
        for br in stimulus:
            neurons=Neuron(brain.path,br)
            for j in range(len(hidden)):
                                #neurons.addPathway(Neuron(brain.path+"Hidden/",words[j])) #link to hidden
                                neurons.addPathway(Neuron(brain.path+"Hidden/",hidden[j]))
        outputs=brain.findResponse(stimulus) #get output
        if len(outputs)>0:
                return  outputs[0][0].name
    def NegFeedback(brain,data,hiddenLayer,outcome):
        #back propogation of the problem will find the error and change weight values
        #loop through hidden edges and find what linked to the wrong areas and decrease
        if outcome !=None:
            hidden=[]
            for j in range(len(hiddenLayer)): #create a list of neurons
                hidden.append(Neuron(brain.path+"Hidden/",hiddenLayer[j]))
            for i in range(len(hidden)):
                cons=hidden[i].getConnections()
                for j in range(len(cons)):
                        nameOf=cons[j][0].split("/")[-1]
                        if nameOf == outcome:
                            #reduce weights
                            cons[j][1]=str(round(float(cons[j][1])*0.90,4)) #decrease by 10%
                        else:
                            cons[j][1]=str(round(float(cons[j][1])*1.10,4)) #increase by 10%
                hidden[i].updateConnections(cons)
            if brain.interact(data,hiddenLayer) == outcome:
                brain.NegFeedback(data,hiddenLayer,outcome)


#area solver
file = open("/home/dexter/Desktop/AI/V_0.0.4/input.txt",'r')
r = file.read()
file.close()
numbers = "1 2 3 4 5 6 7 8 9 0"
output = 0
if "square" in r:
	print("square")
	a = 0
	string = ""
	while a < len(r):
		if r[a] == "=":
			string += r[a+1]
			a += 2
			while a < len(r):
				if r[a] in numbers:
					string+=r[a]
				a += 1
		a += 1
	print(string)
	output = int(string)
	print(output)
	output = output * output
file = open("/home/dexter/Desktop/AI/V_0.0.4/output.txt",'w')
file.write("the area is "+str(output))
file.close()

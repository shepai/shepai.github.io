from tkinter import *
from tkinter import messagebox

root = Tk()

C = Canvas(root, bg="black", height=500, width=400)
root.geometry("500x400")
C.pack()

if __name__ == '__main__':
            mainloop()

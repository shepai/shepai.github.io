#test code for the SHEP AI library
#the arrays represent different objects a camera recognizes at different times of the day
#the camera also sees what happens after each event
from SHEP import AI

inputs=["Blue","Blue cup","dog"]      #objects camera sees
f=AI("",len(inputs)) #create an AI as an object to take in arrays of size 3 (length of array inputs)
f.setPath("test/") #change the pathway to write and read data from
(f.find(inputs)) 
inputs=["pick up cup","Blue cup","distance=90"] #what it sees next
(f.find(inputs))
inputs=["Blue","Blue cup","cat"] #objects seen
(f.find(inputs))
inputs=["pick up cup","Blue cup","distance=1000"]  #what happens after  (distance irrelevant)
(f.find(inputs))
inputs=["cat","milk","dog"] #new objects seen
(f.find(inputs))
inputs=["scare cat","pat dog","distance=287"] #learn to scare the cat off (distance irrelevant)
(f.find(inputs))
inputs=["Blue","Blue cup","mat"] #revise blue cup scenario
(f.find(inputs))
inputs=["pick up cup","Blue cup","distance=1000"] #revise picking that cup up
(f.find(inputs))
inputs=["cat","milk","popping candy"]
(f.find(inputs))
inputs=["scare cat","pat dog","distance=287"]
(f.find(inputs))
inputs=["Blue","Blue cup","distance=400"]
print("test ",inputs,"=============================")
found=(f.find(inputs)) #expecting pick up cup
print("Computer response:",found)
if input("Was this correct (y/n)") == "n":
    f.negFeedback(found,inputs) #teach system using negative feedback
inputs=["cat","popping candy","distance=1000"]
found=(f.find(inputs)) #expecting scare cat
print("Computer response:",found)
if input("Was this correct (y/n)") == "n": #teach system using negative feedback
    f.negFeedback(found,inputs) #teach system

from SHEP import AI

sprite1 = AI("Droid", "Jeffery","Droid.xml") #an AI called 'Jeff' and owned by 'user'
sprite2 = AI("Jeffery", "Jeffery","jeff.xml")
#######################################################
print("\nTwo AI convo two")
value = sprite1.find("how","feeling","are",1) #check data
print("Droid: "+value)
if value != "/00/00/00":
    trigger = sprite2.find_term(value,"t")
    subject = sprite2.find_term(value,"s")
    command = sprite2.find_term(value,"c")
    value = sprite2.find(trigger,subject,command,1) #check data
print("Jeff: "+value)

######################################################
print("\nTwo AI convo one")
value = sprite1.find("how","feeling","are",1) #check data
print("Droid: "+value)

if value != "/00/00/00":
    value = sprite2.search(value)
print("Jeff: "+value)

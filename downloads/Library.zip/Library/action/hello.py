import time
print("Hello, world!")
time.sleep(2)

import sys
import os
import re
import time
import re
string = "The time is."+(time.asctime( time.localtime(time.time()) ))[10:-7]


try:
       #output using onboard TTS
       pixels.speak() #coulourful look
       string = string.replace("'","") #prevent an apostriphe messing it up.
       os.system("espeak '"+string+"' 2>/dev/null")       
except:
           #no connection
           print(string)
           

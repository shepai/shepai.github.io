from SHEP import AI

myBot = AI("Jeff", "user","knowledge.xml") #an AI called 'Jeff' and owned by 'user'

myBot.setpath("")

User = input("Your message ")

r = myBot.search(User)
print(r)

#add phrases to make word
myBot.addWord("boosal4life","t")
myBot.addWord("boosal4life","s")
myBot.addWord("boosal4life","c")

x=myBot.find("boosal4life","boosal4life","boosal4life",0)
print(x) #check data

#put the 1 as a 0 to enable automatic learning

#myBot.edit("what is your name")

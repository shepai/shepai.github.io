from SHEP import AI

myBot = AI("Jeff", "user","knowledge.xml") #an AI called 'Jeff' and owned by 'user'



User = input("Your message ")

r = myBot.search(User)
print(r)
#add phrases to make word
myBot.addWord("how","t")
myBot.addWord("feeling","s")
myBot.addWord("you","c")

print("Robot message: "+myBot.find("how","feeling","you",1)) #check data
print("Robot message: "+myBot.find("no word","no word","no word",1)) #check data
#put the 1 as a 0 to enable automatic learning

myBot.edit("what is your name")

#Code by Dexter Shepherd aged 15
#A low end AI for open source use
#This is a test of an algorithm

from pathlib import Path

def learn():
    global userMessage
    global string
    string = ""
    f = open("ask.txt",'r')
    r = f.read()
    f.close()
    count = 0
    if r != "":
        while count <= len(r):
            c = r[count]
            if(c == '/'):
                break
            else:
                string += c
            count += 1
        f = open("ask.txt",'w')
        f.close()
        print("Robot message: "+"how do I respond to "+"'"+string+"'")
        response = input("user message: ")
        f = open(string+".txt",'w')
        f.write(response)
        f.close()

previous = ""
while True: #main loop
    print("****************************************")
    print("AI SHEPY prototype software             ")
    print("         Version 0.0.1                  ")
    print("         By Dexter Shepherd             ")
    print("         Age 15                         ")
    print("****************************************")
    print("/menu to bring up options               ")
    print("****************************************")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("                                        ")
    print("             -----------                ")
    print("           ---------------              ")
    print("         -------------------            ")
    print("       -------         -------          ")
    print("      -------   *****   -------         ")
    print("      -------  *******  -------         ")
    print("      -------  *******  -------         ")
    print("       -------  *****  -------          ")
    print("        -------       -------           ")
    print("          -----------------             ")
    print("            -------------               ")
    print("              ---------                 ")
    print("                                        ")
    print("                                        ")
    print(previous)
    learn()
    userMessage = input("User message: ")   #get users message
    if userMessage == "/menu":
        print("****************************************")
        print("/info")
        print("/help")
        print("****************************************")
        c = input("-> ")
        if c == "/help":
            print("For more info go to shepai.github.io")
        elif c == "/info":
            print("This appplication was set up as a test")
            print("for future SHEP algorithms. It is a ")
            print("'dumbed' down version of SHEP, it is to")
            print("test out smarter alternitives to improve")
            print("SHEPs intelligence")
        else:
            print("no such command '"+c+"'")
    else:
        my_file = Path(userMessage +".txt")
        if my_file.is_file():
            f = open(userMessage+".txt",'r')
            r = f.read()
            f.close()
            previous = "Robot message: "+r
            
            learn()
        else:
            print("I'm not sure what to say")
            f = open("ask.txt",'a')
            f.write(userMessage)
            f.write("/")
            f.close()
        

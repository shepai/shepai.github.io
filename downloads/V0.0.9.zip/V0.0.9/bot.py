from AI import CB
import sys

cleverBot=CB(sys.path[0].replace("\\","/")+"/testCB/")

while True:
    userInput=input(">") #get user input
    x=cleverBot.chat(userInput)
    print(x)

___Version___="0.1.3"
___Author___ ="Dexter Shepherd"
import xml.etree.ElementTree as ET
#for Python version 3 or above
import sys
import os
import re
import time
from subprocess import *
from nodes import *
from database import datafile
#####################################
from urllib.request import urlopen
import urllib


class AI:
       global system_pathway
       global subjectOfDiscussion
       
       system_pathway = ""
       subjectOfDiscussion=""
       def __init__(myAI, name, user,file, intelligence):
           myAI.name = name
           myAI.age = user
           myAI.file = file
           myAI.listOfVocab = []
           myAI.num_of_commands = 0
           myAI.intelligence=1-intelligence
           myAI.topicOfDiscussion=""
       def setFile(myAI,string):#set the file to a different one
              myAI.file = string
       def setpath(myAI,string):#set the file to a different one
              global system_pathway
              system_pathway = string
       def update(myAI):
              try:
                     file = open(system_pathway+"test.txt","w")
                     for line in urlopen("https://shepai.github.io/code/SHE4P.py"):
                            #decode the file and write it to the Pi
                            s = line.decode('utf-8')
                            ##print(s)
                            file.write(s)
                     file.close()
                     
                     file = open(system_pathway+"test.txt","r")
                     r = file.read()
                     file.close()
                     current = open(system_pathway+"SHEP.py","r")
                     r2 = current.read()
                     current.close()
                     if(r != r2):#same
                            #update
                            #myAI.out("updating...")
                            current = open(system_pathway+"SHEP.py","w")
                            current.write(r)
                            current.close()
                            os.system("sudo reboot")    #restart with new
              except:
                     print("Error finding update")
       def checkFile(myAI,wordList, file):
              #check where the words lead
              tree = ET.parse(file)
              root = tree.getroot()
              counter=0
              for graph in root.findall('phrase'):
                   words = graph.find('words').text #check the words saved
                   
                   if words == None:
                          words=" "
                   words=words.split() #split for check
                   if wordList == words:
                        #the current word is found
                        nextnode=graph.find('output').text #get the file attached
                        return nextnode
                   counter+=1
               
              return False
       def convertToString(myAI,List):
              #convert an array to a asentence of strings
              word=""
              for i in range(len(List)):
                     #make a string
                     word+=List[i]+" "
              return word[:-1]
       def writeFile(myAI,wordList,filepath,filename):
              #write to file in the correct format
              
              file = open(system_pathway+filename,"r")    #open database
              r = file.read() #read data
              file.close()
              r = r.replace("</data>","") #remove end
              r = r + "\t<phrase>\n"
              r = r + "\t<words>"+myAI.convertToString(wordList)+"</words>\n"
              r = r + "\t<output>"+filepath+"</output>\n"
              r = r + "\t</phrase>\n"
              r = r + "\t</data>\n"
              file = open(system_pathway+filename,"w")    #open database
              file.write(r) #write to file
              file.close()
       def checkPath(myAI,filename):
              #check a file is genuine
              try: #try open it
                     file=open(system_pathway+filename,"r")
                     file.close()
                     return True
              except:
                     return False
       def debug(myAI,string):
              #print("debug message>>>"+str(string))
              x=0
       def addResponse(myAI,file,subjects,data):
              #add a new response to the file
              myAI.debug(file)
              myAI.writeFile(subjects.split(),data,file)
       def downloadNew(myAI,dataEntry,subject):
              #download data on a specific subject and talk about it
              myAI.debug("Donwloading file on "+subject)
              #dataEntry=datafile(stripped)
              found=dataEntry.download(subject)#download info
              if found != "":
                     try: #add to existing
                            file=open(system_pathway+subject.replace(" ","+")+".txt",'a')
                     except: #add new
                            file=open(system_pathway+subject.replace(" ","+")+".txt",'r')
                     file.write(found)
                     file.close()
                     fileList=open(system_pathway+"fileList.txt","a")
                     fileList.write(","+system_pathway+subject.replace(" ","+")+".txt")
                     fileList.close()
              
       def findkeywords(myAI,file,sub):
              #find words used to answer simular questions
              tree = ET.parse(file)
              root = tree.getroot()
              words=""
              sub=sub.split()
              for graph in root.findall('phrase'):
                   words+=(graph.find('output').text)+" " #find all answers
              for i in range(len(sub)):
                     #split and remomve subject
                     words=words.replace(sub[i],"")#take out subject
              return words
       def getDataList(myAI):
              fileList=open(system_pathway+"fileList.txt","r")
              r=fileList.read()
              r=r.replace("\n","")
              fileList.close()
              return r
       def checkDB(myAI,sig,res,r):
              #check the saved databases for information
              myAI.debug("files: "+r)
              stripped=r.split(",")
              dataEntry=datafile(stripped)
              query=""
              if res == "":
                     query=dataEntry.search(myAI.convertToString(sig))#gather info
                     res=myAI.convertToString(sig)
              else:
                     query=dataEntry.search(res)#gather info
              if len(query) >= 1: #there are multiple items
                     #refine search
                     percentages=dataEntry.percentages(query,res,myAI.convertToString(sig))
                     largest=0
                     index=0
                     for i in range(len(percentages)):
                            
                            if (largest) < (percentages[i]):
                                   #find the largest
                                   largest=percentages[i]
                                   if res in query[i]: #if exact subject in, increase chance
                                          largest+=0.4
                                   index=i
                            if i>0:#check there is one behind
                                   check=dataEntry.cons(query[i-1],query[i])
                                   if check != "":#check if words are together
                                          query[index]=check
                     myAI.debug("largest"+str(largest))
                     threshold=(1-myAI.intelligence)-0.25
                     if largest <threshold: #not significant
                            
                            return ""
                     else:
                            return ">>"+query[index]
                     
              else:
                     return ""
       def replyToSubject(myAI,sigWords,result):
              #function to look in current file for valid information
              #if information is found it returns it, if not it
              myAI.debug("check using old subject")
              returned=""
              
              if subjectOfDiscussion != "":
                     List=os.listdir(system_pathway+"files/")
                     index=myAI.getFileName(List,sigWords,result)#get the file
                     returned=myAI.checkDB(sigWords,result,subjectOfDiscussion)
              return returned

       def simularNames(myAI,currentwords):#enter words as list and get respondent words
              correspondent=[]
              listofcurrent=currentwords
              currentwords=myAI.convertToString(currentwords)
              
              wordsnotfound=""
              #check where the words lead
              tree = ET.parse("correspondent.xml")
              root = tree.getroot()
              found=""    
              for graph in root.findall('phrase'):
                          words = graph.find('words').text #check the words saved
                          
                          if words == None:
                                 words=""
                          
                          if words in currentwords:
                               #the current word is found
                               nextnode=graph.find('output').text #get the file attached
                               correspondent.append(nextnode) #add replacement word
                               found+=words
                               
                          else:
                                 #make sure old terms and the same word is not added
                                 wordsnotfound+=(currentwords.replace(found,"")).replace(wordsnotfound,"")
              print("-=-=-=-=-=-=-=-=-=")
                     #find each word in datafile
              #replace words with unused
              currentwords=myAI.convertToString(correspondent)
              currentwords=currentwords.replace(" _",wordsnotfound)
              return currentwords #return sentence to search with
       def getFileName(myAI,List,sigWords,result):
              #find the file name with relevanvce
              current=0
              relevency=0
              index=-1
              for i in range(len(List)): #loop through files
                            
                            if ".xml" in List[i]:
                                   
                                   counter=0
                                   words=(List[i].replace(".xml","")).split()
                                   for j in range(len(words)): #loop through file
                                          if words[j] in sigWords:
                                                 counter+=1 #increase counter
                                   
                                   if counter > len(sigWords)*0.5: #at least 50% match
                                          tempRel=0
                                          file=open(system_pathway+"files/"+List[i],'r') 
                                          r=file.read() #attempt to find if relevant information is within this file
                                          file.close()
                                          temp=result.split()
                                          for j in range(len(temp)):
                                                 if temp[j] in r:
                                                        tempRel += 1/(len(temp))
                                          tempRel=tempRel*100 #get in percent form
                                          myAI.debug("could be in: "+List[i]+" with chance: "+str(tempRel)+"%  "+str(counter)+" times") 
                                          if counter >= current and relevency <= tempRel: #check this file
                                                 if index >=0 and counter == current and relevency == tempRel: #a reset is happening with equal chance
                                                        if sigWords[0] in List[i]:
                                                               #if the first word is in the file
                                                               #first word is usuall important
                                                               #keep same otherwise
                                                               index = i
                                                 else:
                                                        index=i
                                                        current=counter #save new to variable
                                                        relevency=tempRel
              return index
       def learn(myAI,result,sigWords):
              #function to learn information
              found = False
              output=">>failed to find response>>"
              index=-1
              List=os.listdir(system_pathway+"files/")
              try: #find if the file exists
                     file=open(system_pathway+"files/"+myAI.convertToString(sigWords)+".xml","r")
                     file.close()
                     file=system_pathway+"files/"+myAI.convertToString(sigWords)+".xml"
                     for i in range(len(List)): #find the index
                            if List[i] == myAI.convertToString(sigWords)+".xml":
                                   index=i
                     myAI.debug(str(index))
              except:      
                     index=myAI.getFileName(List,sigWords,result)
              if index >= 0: #something was found
                            file=system_pathway+"files/"+List[index]
                            myAI.debug("data found in "+file)
                            tree = ET.parse(file)
                            root = tree.getroot()
                            returned=False
                            significanceThreshold = 0.5
                            wordList=result.split()#split the terms down
                            if result == "": #if there are no words, try find any old ones
                                   #this will only be a problem with short phrases like "how are you"
                                   result=myAI.convertToString(sigWords)
                                   significanceThreshold=0.2 #set lower threshold to make it easier
                                   wordList=result.split()#split the terms down
                                   #make sure the threshold is kind to the word
                            elif len(wordList) <= 3: #small word
                                   significanceThreshold = (myAI.intelligence*100)+19
                            elif len(wordList)>=6: #large word
                                   significanceThreshold = (myAI.intelligence*100)-19
                            if significanceThreshold>100:#check its in bounds
                                   significanceThreshold=100
                            elif significanceThreshold<0:#check its in bounds
                                   significanceThreshold=0
                            for graph in root.findall('phrase'): #loop through to find everything
                                 counter=0
                                 words = graph.find('words').text #check the words saved
                                 if words == None:
                                        words=" "
                                 words=words.split() #split for check
                                 myAI.debug(str(words)+str(wordList)+str(counter))
                                 for i in range(len(wordList)): #check recurrence
                                        
                                        if wordList[i] in words:
                                              counter+=1
                                              if counter/len(wordList) > significanceThreshold: #half chance
                                                    #the current word is found
                                                    returned=graph.find('output').text #get the file attached                    
                            if returned != False: #something is found
                                          output=returned #set the value to give back as the saved phrase
                                          
                            else: #next level of checking
                                   returned=myAI.checkFile(result.split(),file)#get output
                                   myAI.debug("The data "+str(returned))
                                   if returned != False: #something is found
                                          output=returned
                                   else:
                                          output+=(result)+">>"+file
              else: #nothing was found
                            #myAI.writeFile(result.split(),response,"files/"+myAI.convertToString(sigWords)+".xml")
                            myAI.debug("file write")
                            myAI.writeFile(sigWords,"files/"+myAI.convertToString(sigWords)+".xml","sig.xml")
                            file = open("files/"+myAI.convertToString(sigWords)+".xml","w")
                            file.write("<data>\n</data>")
                            file.close()
                            file=system_pathway+"files/"+myAI.convertToString(sigWords)+".xml"
                            output+=(result)+">>"+file
              myAI.debug("file name:"+file)
              if ">>failed to find response>>" in output:
                     keys=myAI.findkeywords(file,result) #find ways of approaching sentences like this
                     if keys=="": #no data
                            keys=myAI.convertToString(sigWords)
                     result=f.simularNames(result) #get the best words for checking
                     finalcheck=myAI.checkDB(keys,result,myAI.getDataList()) #check the database for info
                     if finalcheck != "": #if something is found
                            output = finalcheck +">>"+result+">>"+file
                     else: #try download new info and read
                            fileList=open(system_pathway+"fileList.txt","r")
                            r=fileList.read()
                            r=r.replace("\n","")
                            fileList.close()
                            stripped=r.split(",")
                            dataEntry=datafile(stripped)
                            myAI.downloadNew(dataEntry,result)#download new info
                            finalcheck=myAI.checkDB(keys,result,myAI.getDataList()) #check the database for info
                            if finalcheck != "": #if something is found
                                   output = finalcheck +">>"+result+">>"+file
              return output #show the user what is found
       def find(myAI,userinput):
              global subjectOfDiscussion
              #main part of algorithm
              Node=tree("tree")
              Node.search("path",userinput)#check the nodes with all words
              words=userinput.split()
              sigWords=[]#significant words
              for i in range(len(words)):
                     if Node.significant("path",words[i]):
                            sigWords.append(words[i])
              
              resultwords  = [word for word in words if word not in sigWords]
              result = ' '.join(resultwords) #find the non used words
              myAI.debug("sig words:"+str(sigWords))
              myAI.debug("other:"+str(result))
              
              number=Node.getNodeNum("path")
              if number >= 100: #significant amount to start learning
                            returned = myAI.checkFile(sigWords,'sig.xml') #check file
                            
                            returned2=myAI.learn(result,sigWords)#learn the data to add
                            returned3=myAI.replyToSubject(sigWords,result)#check current data
                            if returned != False: #something is found
                                   returned1=myAI.checkFile(result.split(),returned)#get output
                                   if returned1 != False:
                                          myAI.debug("Found straight away")
                                          subjectOfDiscussion=result.replace(" ","+")+".txt"
                                          
                                          return returned1
                                   elif returned3 != "":
                                          myAI.debug("FOund by using old data")
                                          returned3=returned3.replace(">>","")
                                          return returned3       
                                   else:
                                          myAI.debug("FOund by infering")
                                          subjectOfDiscussion=result.replace(" ","+")+".txt"
                                          return returned2
                            else:
                                   #there is no file found
                                   myAI.debug("no file found")
                                   if returned3 != "":
                                          myAI.debug("Found by using old data")
                                          returned3=returned3.replace(">>","")
                                          return returned3
                                   else:
                                          myAI.debug("Found by infering")
                                          subjectOfDiscussion=result.replace(" ","+")+".txt"
                                          return returned2
                                   
                                   
                                   
                            
                     
f=AI("SHEP","Dexter","knowledge.xml",0.7) #0.7 is acceptable average

while True:
       x=input("User input: ")
       if ">" in x:
              print("Robot message: Invalid character detected")
       else:
              get=f.find(x)
              if ">>failed to find response>>" in get:
                     get=get.replace(">>failed to find response>>","")
                     get=get.split(">>")
                     response=input("How shall I respond?: ")
                     f.addResponse(get[1],get[0],response)
                     Node=tree("tree")
                     Node.search("path",response)#add to the database to improve speaking

                     #print("Robot message: I will need to add information on '"+get[0]+"' in '"+get[1]+"'")
              elif ">>" in get: #found relevent info
                     get = get.split(">>")
                     print("robot message:",get[1]) #output and check is correct
                     print("robot message: Did I answer correctly? ")
                     
                     x=input("User input: ")
                     if x== "yes":
                           f.addResponse(get[3],get[2],get[1])
                           Node=tree("tree")
                           Node.search("path",get[1])#add to the database to improve speaking
                     else:
                           response=input("How shall I respond?: ")
                           f.addResponse(get[3],get[2],response)
                           Node=tree("tree")
                           Node.search("path",response)#add to the database to improve speaking
              else: #actual saved info is found
                     print("robot message:",get)
       
#print(f.research(x))
#f.learn(f.listOfVocab,input("answer:"))

"""
LED light pattern like Google Home
"""

#this file is a mock up of the LED board
import time

class Pixels:
    PIXELS_N = 3

    def __init__(self):
        print("Load pixels")

    def wakeup(self, direction=0):
        print("Wakeup face")

    def listen(self):
        print("listen face")

    def think(self):
        print("think face")

    def speak(self):
        print("speak face")

    def off(self):
        print("off")

    def _run(self):
        print("start run")

    def _wakeup(self, direction=0):
        print("Wakeup face")
    def _listen(self):
        print("listen face")

    def _think(self):
        print("think face")


    def _speak(self):
        print("speak face")
        # self._off()

    def _off(self):
        print("off")

    def write(self, colors):
        print("write face",colors)


pixels = Pixels()


if __name__ == '__main__':
    while True:

        try:
            pixels.wakeup()
            time.sleep(3)
            pixels.think()
            time.sleep(3)
            pixels.speak()
            time.sleep(3)
            pixels.off()
            time.sleep(3)
        except KeyboardInterrupt:
            break


    pixels.off()
    time.sleep(1)

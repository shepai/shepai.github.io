from SHEP import AI
from database import datafile
from nodes import *
import sys
global system_pathway
system_pathway=sys.path[0]+"/"+"data/"
f=AI("SHEP","Dexter","knowledge.xml",0.7) #0.7 is acceptable average
f.setpath(system_pathway)

def OUTPUT(string):
       #main output
       print("robot message:",string)
def INPUT(string):
       #main input method
       print(string)
       return input()
def add(data1,data2):
       #add data
       response=INPUT("How shall I respond?: ")
       if response.lower() == "cancel" or response.lower() == "never mind":      
              OUTPUT("Sure")
       else:
              f.addResponse(data1,data2,response)
              Node=tree(system_pathway,"tree")
              Node.search("path",response.replace(".","").replace(",","").replace("?","").replace(";",""))#add to the database to improve speaking
                                  
while True:
       x=INPUT("User input: ")
       if ">" in x:
               OUTPUT("Invalid character detected")
       else:
              get=f.find(x)
              if ">>failed to find response>>" in get:
                     get=get.replace(">>failed to find response>>","")
                     get=get.split(">>")
                     add(get[1],get[0])
                     
                     #print("Robot message: I will need to add information on '"+get[0]+"' in '"+get[1]+"'")
              elif ">>" in get: #found relevent info
                     get = get.split(">>")
                     OUTPUT(get[1]) #output and check is correct
                     OUTPUT("Did I answer correctly? ")
                     
                     x=INPUT("User input: ")
                     if x== "yes":
                           f.addResponse(get[3],get[2],get[1])
                           Node=tree(system_pathway,"tree")
                           Node.search("path",get[1].replace(".","").replace(",","").replace("?","").replace(";",""))#add to the database to improve speaking
                     else:
                           add(get[3],get[2])
                           
                           
              else: #actual saved info is found
                     OUTPUT(get)

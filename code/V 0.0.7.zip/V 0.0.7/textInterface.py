from SHEP import AI
from database import datafile
from nodes import *
import sys
f=AI("SHEP","Dexter","knowledge.xml",0.7) #0.7 is acceptable average
f.setpath(sys.path[0]+"/")

while True:
       x=input("User input: ")
       if ">" in x:
              print("Robot message: Invalid character detected")
       else:
              get=f.find(x)
              if ">>failed to find response>>" in get:
                     get=get.replace(">>failed to find response>>","")
                     get=get.split(">>")
                     response=input("How shall I respond?: ")
                     f.addResponse(get[1],get[0],response)
                     Node=tree("tree")
                     Node.search("path",response.replace(".","").replace(",","").replace("?","").replace(";",""))#add to the database to improve speaking

                     #print("Robot message: I will need to add information on '"+get[0]+"' in '"+get[1]+"'")
              elif ">>" in get: #found relevent info
                     get = get.split(">>")
                     print("robot message:",get[1]) #output and check is correct
                     print("robot message: Did I answer correctly? ")
                     
                     x=input("User input: ")
                     if x== "yes":
                           f.addResponse(get[3],get[2],get[1])
                           Node=tree("tree")
                           Node.search("path",get[1].replace(".","").replace(",","").replace("?","").replace(";",""))#add to the database to improve speaking
                     else:
                           response=input("How shall I respond?: ")
                           f.addResponse(get[3],get[2],response)
                           Node=tree("tree")
                           Node.search("path",response.replace(".","").replace(",","").replace("?","").replace(";",""))#add to the database to improve speaking
              else: #actual saved info is found
                     print("robot message:",get)

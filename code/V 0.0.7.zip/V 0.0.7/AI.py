___Version___="0.0.7"
___Author___ ="Dexter Shepherd"
from SHEP import AI #found in folder
#eye
import time
import colorsys
from pixels import Pixels #found in folder
#import the internet connection libraries
try:
       import httplib
except:
       import http.client as httplib
from urllib.request import urlopen
from wifi import Cell, Scheme
#clear up type errors
from subprocess import Popen, STDOUT, PIPE
from subprocess import *
import subprocess
import os
import re
#parallel programming
import _thread as thread
#speech recognition lib
import speech_recognition as sr
pixels = Pixels()

def internet():
       conn = httplib.HTTPConnection("www.google.com", timeout=5) #attempt connection
       try:
           conn.request("HEAD", "/")
##           conn.close()
           return True #show there is a connection
       except:
           conn.close()
           error_pixels()
           return False #show there is not a connection
def error_pixels():
       #the pixels desplayed for an error
       pixels.off()
       pixels.wakeup()
       time.sleep(0.2)
def OUTPUT(string):#output method
    #locate the arduino port
    try:
       #output using onboard TTS
       print(string)
       pixels.speak() #coulourful look
       string = string.replace("'","") #prevent an apostriphe messing it up.
       os.system("espeak '"+string+"' 2>/dev/null")
       
    except:
           #no connection
           print(string)
           error_pixels()
def getVoice():#input method
       voiceReply =""
       print("here 1")
       try:
           rec = sr.Recognizer()
           rec.dynamic_energy_threshold = False #set ackground noise to silence
           t0 = 0 #set the timer
           print("here 2")
           #rec.energy_threshold = 50
           
           with sr.Microphone() as source:
                  print("here 3")
                  rec.adjust_for_ambient_noise(source) #adjust audio
                  print("here 4")
                  
                  print ("Speak Now")
                  t0 = time.time() #start a timer to prevent the search going on too long
                  pixels.listen()    #output eye to the user
                  audio = rec.listen(source,timeout=5)                   # listen for the first phrase and extract it into audio data
           t1 = time.time() #take a second reading of the time
           total = t1-t0 #work out how long it took
           pixels.off() #stop the LEDs
           print(">>")
           timer = 0
           if total < 15: #it will take too long to convert otherwise
                      try:
                             voiceReply = (rec.recognize_google(audio,language = "en-GB"))
                             print("you said "+str(voiceReply))
                             if "could not understand" in voiceReply.lower(): #prevent annoying output
                                    voiceReply = ""
                      except:
                             voiceReply="" 
           else:
                      print("I'm sorry, I didn't get that")
       
       except:
              voiceReply =""
                      
       return voiceReply #return voice

################################################################################
#
#Below performs the main algorithm binding all the SHEP libraries together
#
################################################################################

myBot = AI("SHEP", "user","knowledge.xml") #SHEP is called in
system_pathway = "/home/shep/Documents/AI/V0.0.7/"
myBot.setpath(system_pathway)
while True:
       x=input("User input: ")
       get=myBot.find(x)
       if ">>failed to find response>>" in get:
              get=get.replace(">>failed to find response>>","")
              get=get.split(">>")
              response=input("How shall I respond?: ")
              myBot.addResponse(get[1],get[0],response)
              #print("Robot message: I will need to add information on '"+get[0]+"' in '"+get[1]+"'")
       else:
              print("robot message:",get)

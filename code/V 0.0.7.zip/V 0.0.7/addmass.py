from nodes import *
import re

file=open("page.txt","r")
r=file.read()
file.close()
r=r.lower()
r=r.replace("?","")
r=r.replace(",","")
r=re.sub(r'\(.*\)', '', r)
r=r.split(".")

treething=tree("gfds")

for i in range(len(r)-1):
    treething.search("path",r[i])
print("done one")

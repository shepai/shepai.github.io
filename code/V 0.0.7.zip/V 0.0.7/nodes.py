import xml.etree.ElementTree as ET
import sys
global system_pathway
system_pathway=""
class tree():
    def __init__(NODE,pathway,file):#initializer
        global system_pathway
        system_pathway=pathway
        NODE.file=file
    def openNode(NODE,pathway,word):
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        position_checker=False #checks to see if changes need to be made
        for graph in root.findall(pathway):
            wordCurrent = graph.find('word').text
            if wordCurrent == word:
                        #the current word is found
                        position_checker = True
                        node=graph.find('node_to').text
                        return node
        
        return False
    def theNextNode(NODE,pathway,node):
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        counter=0
        for graph in root.findall(pathway):
            currentNode = graph.find('node').text
            
            if currentNode == node:
                 #the current word is found
                 nextnode=graph.find('node_to').text
                 return nextnode
            counter+=1
        
        return False
    def getPrevious(NODE,pathway,node):
        #get previous node
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        nodes=[]
        for graph in root.findall(pathway):
            nodeCurrent = graph.find('node_to').text#get the word
            if nodeCurrent == node:
                    #Find the position of word
                    nodes.append(graph.find('node').text)
        return nodes #returns the nodes
    def getNode(NODE,pathway,word):
        #use the word to find the node current
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        for graph in root.findall(pathway):
            wordCurrent = graph.find('word').text#get the word
            if wordCurrent == word:
                    #Find the position of word
                    nodeCurrent = graph.find('node').text
                    return nodeCurrent #returns the word at the node
    def getWord(NODE,pathway,node):
        #get the word wanted
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        
        for graph in root.findall(pathway):
            nodeCurrent = graph.find('node').text#get the word
            if nodeCurrent == node:
                    #Find the position of word
                    wordCurrent = graph.find('word').text
                    return wordCurrent #returns the word at the node
    def visitedNode(NODE,pathway,node):
        #get the word wanted
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        wordCurrent=""
        for graph in root.findall(pathway):
            nodeCurrent = graph.find('node').text#get the word
            if nodeCurrent == node:
                    #Find the position of word
                    wordCurrent = graph.find('visited').text
                    return wordCurrent #returns the word at the node
        if wordCurrent == "":
            return "1"
    def writeNode(NODE,Type,word,node,nodeTo):
        #add a new node
        file = open(system_pathway+"tree.xml","r")    #open database
        r = file.read() #read data
        file.close()
        r = r.replace("</data>","") #remove end
        r = r + "\t<"+Type+" num="+'"1\">\n'
        r = r + "\t<word>"+word+"</word>\n"
        r = r + "\t<visited>"+NODE.visitedNode(Type,node)+"</visited>\n"
        r = r + "\t<node>"+str(node)+"</node>\n"
        r = r + "\t<node_to>"+str(nodeTo)+"</node_to>\n"
        r = r + "\t</"+Type+">\n"
        r = r + "\t</data>\n"
        file = open(system_pathway+"tree.xml","w")    #open database
        file.write(r) #write to file
        file.close()
    def getNodeNum(NODE,pathway):
        #count the nodes
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        
        counter=1
        for graph in root.findall(pathway):
            counter+=1
        return counter
    def replaceNode(NODE,Type,word,node,nodeTo,visited):
        #replace old node
        file = open(system_pathway+"tree.xml","r")    #open database
        r = file.read() #read data
        file.close()
        f=""
        g=""
        f = f + "\t<"+Type+" num="+'"1\">\n'
        f = f + "\t<word>"+word+"</word>\n"
        f = f + "\t<visited>"+NODE.visitedNode(Type,node)+"</visited>\n"
        f = f + "\t<node>"+str(node)+"</node>\n"
        f = f + "\t<node_to>"+NODE.openNode(Type,word)+"</node_to>\n"
        f = f + "\t</"+Type+">\n"
        
        #print("f---"+"/n"+f)
        
        g = g + "\t<"+Type+" num="+'"1\">\n'
        g = g + "\t<word>"+word+"</word>\n"
        g = g + "\t<visited>"+visited+"</visited>\n"
        g = g + "\t<node>"+str(node)+"</node>\n"
        g = g + "\t<node_to>"+str(nodeTo)+"</node_to>\n"
        g = g + "\t</"+Type+">\n"
        
        #print("g---"+"/n"+g)
        r = r.replace(f,g)
        file = open("tree.xml","w")    #open database
        file.write(r) #write to file
        file.close()
    def traverseDepth(NODE,startNode):
        stack=[]#store each of nodes in
        nodesTo=[]#store nodes on each layer not used
        visited=[]#boolean if visited
        text=[]#store text phrases
        
        nextNode = startNode.replace("!S!","")
        notVisited=[]#store those not visited
        finished=False
        counter=0#counts size of arrays
        pointer=0#stack position
        #get the word wanted
        tree = ET.parse('tree.xml')
        root = tree.getroot()
        wordCurrent=""
        for graph in root.findall('answer'):
            nodeCurrent = graph.find('node').text#get the node
            
            visited.append(False)
            nodesTo.append(graph.find('node_to').text)#get the node to
            text.append(graph.find('word').text)#get the word
            
            
            
            
        print("Nodes|Visited|NodesTo|Text")
        print("--------------------------")
        for i in range(len(nodesTo)):
                
                print(i+1,"|",visited[i],"|",nodesTo[i],"|",text[i])
            
    def query(NODE,Type):
        #find correlations
        print("correlations")
    def find(NODE,Type,words):
        complete=False
        output=""
        firstFound=True #sets there is a found word
        added=[]
        while(complete == False):
            word=words.split()
            first = NODE.openNode(Type,word[0]) #get the first node
            
            if first:
                #if the word is there
                node=first
                if len(word) > 1: #more than one word
                    oldNode=first
                    for i in range(len(word)-1):
                        place = i+1
                        #none=theNextNode('path',node)
                        node=NODE.openNode(Type,word[place])
                        #check if the previous word existed
                        
                        if node:
                            #if it exists
                            
                            if firstFound==False:
                                
                                num=NODE.getNodeNum(Type)#get the amount there are
                                
                                #replace the old node with new node
                                finder=NODE.openNode(Type,word[place-1])
                                if finder != "!":
                                    num=finder+","+str(num)
                                NODE.replaceNode(Type,word[place-1],NODE.getNode(Type,word[place-1]),NODE.getNode(Type,word[place]),NODE.visitedNode(Type,NODE.getNode(Type,word[place-1])))
                                firstFound=True #set back to how it should be
                            
                            if "!S!" in node and len(getPrevious('path',oldNode)) != len(node.split(",")):
                                #the final node
                                #must be checked if previous words match
                                tree = ET.parse(system_pathway+'tree.xml')
                                root = tree.getroot()
                                
                                for graph in root.findall(Type):
                                    nodeCurrent = graph.find('node_to').text#get the word
                                    if nodeCurrent == node:
                                            #Find the position of word
                                            oldNode = graph.find('node').text
                                
                                previous=NODE.getPrevious('path',oldNode)
                                for i in range(len(previous)):
                                    if NODE.getWord(Type,previous[i]) ==word[place-1]:
                                        #The word prior to this one has same node
                                        
                                        NODE.replaceNode(Type,word[place],NODE.getNode(Type,word[place]),node+",!",NODE.visitedNode(Type,NODE.getNode(Type,word[place])))
                            else:
                                nodes=node.split(",")
                                for j in range(len(nodes)):
                                    if place+1<=len(word)-1:
                                        #there is room for more words
                                        if NODE.getWord(Type,nodes[j])==word[place+1]:
                                            node=nodes[j]
                                    else:
                                        #there are no more words afterwards
                                        #add a solution
                                        x=0
                        else:
                            #it does not
                            
                            num=NODE.getNodeNum(Type)#get the amount there are
                            NODE.writeNode(Type,word[place],num,'!')
                            added.append(word[place])#add to the added words array
                            #replace the old node with new node
                            finder=NODE.openNode(Type,word[place-1])
                            visit=NODE.visitedNode(Type,NODE.getNode(Type,word[place-1]))
                            if finder != "!":
                                num=finder+","+str(num)
                                visit=str(int(NODE.visitedNode(Type,NODE.getNode(Type,word[place-1]))))
                            NODE.replaceNode(Type,word[place-1],NODE.getNode(Type,word[place-1]),num,visit) #the num (node to go to) increasess after one has been added
                        oldNode=node
                
                    #there is not a reply output will be ""
                complete=True
            else:
                #there is not a node
                NODE.writeNode(Type,word[0],NODE.getNodeNum(Type),'!')#write one
                added.append(word[0])#add to the added words array
                firstFound=False #sets there is no found word
        #add one to everything other than what was added
        #has anything been added?
        if len(added) > 0:
            #it has
            words=" "+words+" "#forat for removal
            for i in range(len(added)):
                words=words.replace(" "+added[i]+" "," ")
                
            word=words.split()
            
            for i in range(len(word)):
                #increase each old word
                NODE.replaceNode(Type,word[i],NODE.getNode(Type,word[i]),NODE.theNextNode(Type,NODE.getNode(Type,word[i])),str(int(NODE.visitedNode(Type,NODE.getNode(Type,word[i])))+1)) #the num (node to go to) increasess after one has been added
        
    def search(NODE,Type,word):
        #do a search using nodes
        #will only work if everything is already written into the data
        NODE.find(Type,word)
        words=word.split()
        node=NODE.getNode(Type,words[0]) #get the first node
        count=1
        counter=0
        for i in range(len(words)-1):
            count=1+i
            nodes=NODE.theNextNode(Type,node)
            
            nodes=nodes.split(",") #get every node
            
            for j in range(len(nodes)): #check every node
                if count <= len(words):
                    if NODE.getWord(Type,nodes[j]) == words[count]: #check word is present
                        counter+=1
                        node=nodes[j]
                        
                        break #not needed but here for stopping future bugs
                
    def show(NODE):
        file = open(system_pathway+"tree.xml","r")    #open database
        r = file.read() #read data
        file.close()
        print(r)
    def dele(NODE):
        file = open(system_pathway+"tree.xml","w")
        file.write("<data>\n\n</data>")
        file.close()
    def significant(NODE,pathway,word):
        #get the times visited
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        num=NODE.getPop(pathway)
        for graph in root.findall(pathway):
            wordCurrent = (graph.find('word').text)#get the word
            if wordCurrent==word:
                #the word matches
                visit=int(graph.find('visited').text)
                if visit>num:
                    #in bound of significance
                    return True
    def getPop(NODE,pathway):
        #find the most popular words
        tree = ET.parse(system_pathway+'tree.xml')
        root = tree.getroot()
        averages=0
        counter=0
        highest=0
        squared=0
        for graph in root.findall(pathway):
            wordCurrent = int(graph.find('visited').text)#get the word
            averages+=(wordCurrent)
            squared+=wordCurrent**2
            counter+=1
            if wordCurrent>highest:
                highest=wordCurrent
        averages=averages/counter#find the average
        UB=(averages/2)*3
        LB=(averages/2)
        SD=((squared/counter)-(averages)**2)**0.5
        #print("Lower:",LB,"\nUpper:",UB,"\nAverage:",averages,"\nHigh:",highest,"\nSD:",SD)
        #for graph in root.findall(pathway):
        #    wordCurrent = int(graph.find('visited').text)#get the word
        #    if wordCurrent>averages+SD:
        #        print(graph.find('word').text,wordCurrent)
        return averages+SD

#########################################
'''
treething=tree("gfds")

while True:
    treething.getPop("path")
    treething.search("path",input())

import re
file=open("questions","r")
r=file.read()
file.close()
r=r.lower()
r=r.replace("?","")
r=r.replace(",","")
r=r.replace(".","")
r=re.sub(r'\(.*\)', '', r)
r=r.split("\n")
treething=tree("gfds")
#treething.dele()

for i in range(len(r)-1):
    treething.search("path",r[i])
print("done one")
file=open("sentence.txt","r")
r=file.read()
file.close()
r=r.replace("?","")
r=r.replace(",","")
r=r.replace(".","")
r=re.sub(r'\(.*\)', '', r)
r=r.split("\n")

print("-------------")
for i in range(len(r)-1):
    treething.search("path",r[i])



'''

'''
treething=tree("gfds")
treething.dele()
while True:
    treething.search("path",input("hello: "))
#treething.show()
    '''
#print("Done!!!!")

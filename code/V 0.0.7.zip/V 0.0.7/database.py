from nodes import *
from html.parser import HTMLParser
import sys
global system_pathway
system_pathway=""
class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.strict = False
        self.convert_charrefs= True
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)
    def remove_bad(self,data):
        remover=False
        substring=""
        data=data.replace("\n",".")
        data=data.replace("\t",".")
        while ".." in data:
            data=data.replace("..",".")
        data=data.replace(".",". ")
        for i in range(len(data)):
            if data[i] in "{[(":
                remover = True
            elif data[i] in "}])":
                remover=False
            elif remover == False:
                substring+=data[i]
        return substring
class datafile:
    def __init__(data,pathway,pathways):
        global system_pathway
        system_pathway=pathway
        data.pathway=pathways
        
    def search(data,keywords):
        missing=[] #add missing databases
        keywords=keywords.lower()
        temp=keywords
        keywords=keywords.split()
        information=[] #store gathered information
        for i in range(len(data.pathway)):
            try: #open a database
                file=open(system_pathway+data.pathway[i],'r')
                r=file.read()
                file.close()
                r=r.replace('\n','. ')
                r=r.lower()
                toFind=r.find(temp, 0)
                if toFind!= -1: #find exact match
                    fullStop = True
                    counter=toFind
                    while fullStop: #find begining of sentence
                        if r[counter] == "." or counter == 0:
                            fullStop=False
                        else:
                            counter=counter-1
                    counter+=1
                    
                    fullStop = True
                    string=""
                    while fullStop: #find end of sentence
                        if r[counter] == "." or counter == len(r):
                            fullStop=False
                        else:
                            string+=r[counter]
                        counter+=1
                    
                    information.append(string[1:])
                r=r.split(".") #split into sentences
                currentChance=0.49
                
                for i in range(len(r)): #loop through each
                    count=0
                    for j in range(len(keywords)):
                        if " "+keywords[j]+" " in " "+r[i][1:]+" ": #word found in sentence
                            count+=1
                    if count/len(keywords) >= currentChance: #check the information is within
                        currentChance=count/len(keywords)
                        information.append(r[i][1:]) #add information
                
            except: #database not found
                missing.append(data.pathway[i])
        return information #return all records found in gien database
    def percentages(data,refine,keywords,significant):
        #gather the percentage chances
        chance=[]
        stringSig=significant
        stringKey=keywords
        significant=significant.split()
        keywords=keywords.split()
        
        for i in range(len(refine)): #loop through each
            count=0
            for j in range(len(keywords)):
                if " "+keywords[j]+" " in " "+refine[i]+" ": #word found in sentence
                            count+=1
                            #print(keywords[j],"is in",refine[i])
                            for z in range(len(significant)):
                                if " "+significant[z]+" " in " "+refine[i][1:]+" ":
                                    count+=1
                                    
                            if len(refine[i])-2<=len(stringSig+stringKey) and len(refine[i])+2>=len(stringSig+stringKey):
                                count+=1 #check simluar sizes
            anti_infinite=0
            if (len(refine[i][1:].split())-len(keywords)-len(significant)) ==0:
                      anti_infinite=1
            perc=float(count/(len(refine[i][1:].split())-len(keywords)-len(significant)+anti_infinite))
            if perc < 0:
                    perc=perc*-1
            chance.append(perc)
            #print(refine[i],"==",str(float(count/(len(refine[i][1:].split())-len(keywords)-len(significant)+anti_infinite))))
        return chance
    def cons(data,string1,string2):
        #find if data is related to reply with a sentence
        missing=[]
        for i in range(len(data.pathway)):
            try: #open a database
                file=open(system_pathway+data.pathway[i],'r')
                r=file.read()
                file.close()
                r=r.replace('\n','. ')
                r=r.lower()
                if string1 + ". "+string2 in r:
                    return string1 + ". "+string2
            except: #database not found
                missing.append(data.pathway[i])
        return ""
    def download(data,subject):
        #download more data on a subject
        text=""
        try:
            try:
                print((subject).replace(" ","+")+".txt")
                file=open(system_pathway+(subject).replace(" ","+")+".txt","r")
                file.close()
            except:
                from urllib.request import urlopen
                import urllib            
                #use wikipedia
                url = 'https://en.wikipedia.org/wiki/'+(subject).replace(" ","_")
                print(url)
                response = urlopen(url)
                data = response.read()      # a `bytes` object
                text = data.decode('utf-8') # a `str`; this step can't be used if data is binary
                print("Downloading file on "+subject)
                s = MLStripper()
                s.feed(text)
                text= s.get_data()
                text = s.remove_bad(text)
        except:
            #no info found
            #try refine search
            text=""
        return text                
#dataEntry=datafile(["tree.txt","personallog.txt","sentence.txt","questions","thatcher.txt"])
#print(dataEntry.search("a tree is a"))

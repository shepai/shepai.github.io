from nodes import *
from html.parser import HTMLParser

class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.strict = False
        self.convert_charrefs= True
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)
    def remove_bad(self,data):
        remover=False
        substring=""
        data=data.replace("\n",".")
        data=data.replace("\t",".")
        while ".." in data:
            data=data.replace("..",".")
        data=data.replace(".",". ")
        for i in range(len(data)):
            if data[i] in "{[(":
                remover = True
            elif data[i] in "}])":
                remover=False
            elif remover == False:
                substring+=data[i]
        return substring
class datafile:
    def __init__(data,pathways):
        data.pathway=pathways
        
    def search(data,keywords):
        missing=[] #add missing databases
        keywords=keywords.lower()
        keywords=keywords.split()
        information=[] #store gathered information
        for i in range(len(data.pathway)):
            try: #open a database
                file=open(data.pathway[i],'r')
                r=file.read()
                file.close()
                r=r.replace('\n','. ')
                r=r.lower()
                r=r.split(".") #split into sentences
                currentChance=0.49
                for i in range(len(r)): #loop through each
                    count=0
                    for j in range(len(keywords)):
                        if " "+keywords[j]+" " in " "+r[i][1:]+" ": #word found in sentence
                            count+=1
                    if count/len(keywords) >= currentChance: #check the information is within
                        currentChance=count/len(keywords)
                        information.append(r[i][1:]) #add information
                
            except: #database not found
                missing.append(data.pathway[i])
        return information #return all records found in gien database
    def percentages(data,refine,keywords,significant):
        #gather the percentage chances
        chance=[]
        stringSig=significant
        stringKey=keywords
        significant=significant.split()
        keywords=keywords.split()
       
        for i in range(len(refine)): #loop through each
            count=0
            for j in range(len(keywords)):
                if " "+keywords[j]+" " in " "+refine[i]+" ": #word found in sentence
                            count+=1
                            for z in range(len(significant)):
                                if " "+significant[z]+" " in " "+refine[i][1:]+" ":
                                    count+=1
                                    
                            if len(refine[i])-2<=len(stringSig+stringKey) and len(refine[i])+2>=len(stringSig+stringKey):
                                count+=1 #check simluar sizes
            anti_infinite=0
            if (len(refine[i][1:].split())-len(keywords)-len(significant)) ==0:
                      anti_infinite=1
            perc=float(count/(len(refine[i][1:].split())-len(keywords)-len(significant)+anti_infinite))
            if perc < 0:
                    perc=perc*-1
            chance.append(perc)
            #print(str(float(count/(len(refine[i][1:].split())-len(keywords)-len(significant)+anti_infinite))))
        return chance
    def cons(data,string1,string2):
        #find if data is related to reply with a sentence
        missing=[]
        for i in range(len(data.pathway)):
            try: #open a database
                file=open(data.pathway[i],'r')
                r=file.read()
                file.close()
                r=r.replace('\n','. ')
                r=r.lower()
                if string1 + ". "+string2 in r:
                    return string1 + ". "+string2
            except: #database not found
                missing.append(data.pathway[i])
        return ""
    def download(data,subject):
        #download more data on a subject
        text=""
        try:
            from urllib.request import urlopen
            import urllib            
            #use wikipedia
            url = 'https://en.wikipedia.org/wiki/'+(subject).replace(" ","_")
            print(url)
            response = urlopen(url)
            data = response.read()      # a `bytes` object
            text = data.decode('utf-8') # a `str`; this step can't be used if data is binary
            print("Downloading file on "+subject)
            s = MLStripper()
            s.feed(text)
            text= s.get_data()
            text = s.remove_bad(text)
        except:
            #no info found
            #try refine search
            text=""
        return text                
#dataEntry=datafile(["personallog.txt","sentence.txt","questions","thatcher.txt"])
#print(dataEntry.download("Jeremy Hunt"))

___Version___="0.0.6"
___Author___ ="Dexter Shepherd"
from SHEP import AI
import time


myBot = AI("SHEP", "user","knowledge.xml") #SHEP is called in

myBot.setpath("/media/dexter/DEXTER/Python coursework/Library/")
def OUTPUT(string):#output method
    print(string)
def INPUT(string):#input method
    OUTPUT(string)
    return input()
def pickPhrase():
    words = INPUT("Select the words you want: ")
    return words

def add(to_add):
    #get the type to add
    if to_add == "action" or to_add == "an action":
        valid=""
        add=True
        while valid != ">added":
            userInput = INPUT("What is the file name")
            if "cancel" == userInput or "exit" == userInput:
                #allow the user to change their mind and not add
                valid = ">added"
                OUTPUT("I shall not add an action")
            else:
                valid = myBot.addAction(userInput)#check the filename and add
                to_add = ">action"
                
                                    
    
    return to_add

exit = False #exit decider
add_mode = True #defines whether the AI should ADD or not
while exit == False:
    User = INPUT("Your message ")
    r = myBot.search(User)
    
    if User == "edit": #edit a sentence
        sentence = INPUT("Say the sentence that I shall edit ")
        to_add = INPUT("What shall I replace it with? ")
        replace = add(to_add)
        myBot.edit(sentence,replace)
    elif User == "add action":
        myBot.listUSB()
    else:
        if add_mode == True:
            if r == "No trigger": #add phrases to make word
                OUTPUT("No trigger found")
                myBot.addWord(pickPhrase(),"trigger")
                r = ""
            elif r == "No subject": #add phrases to make word
                OUTPUT("No subject found")
                myBot.addWord(pickPhrase(),"subject")
                r = ""
            elif r == "No command": #add phrases to make word
                OUTPUT("No command found")
                myBot.addWord(pickPhrase(),"command")
                r = ""
            elif r == "/actions/": #an action has just been played.
                print("Action played")
                r = ""
            elif r == "/00/00/00": #no action is fond
                print("Learning... a moment please")
                word_to_add = myBot.findWiki(myBot.subject,myBot.command) #check wiki
                
                if word_to_add != "": #if something is found
                        myBot.learn(myBot.trigger,myBot.subject,myBot.command,word_to_add)
                if word_to_add == "":
                    #the wiki is not going to be added
                    to_add = INPUT("Nothing in my data, What shall I add?")
                    to_add = add(to_add)
                    print(to_add)
                    if to_add != ">action" or to_add != "action" or to_add != "an action":
                        
                        myBot.learn(myBot.trigger,myBot.subject,myBot.command,to_add)
                r = ""
        
    OUTPUT("Robot message: "+r)


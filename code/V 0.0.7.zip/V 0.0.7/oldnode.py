import xml.etree.ElementTree as ET

def openNode(pathway,position,word):
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    position_checker=False #checks to see if changes need to be made
    for graph in root.findall(pathway):
        num = graph.get('num')#get each node structure num
        if int(num) == position:
                #Find the position of word
                wordCurrent = graph.find('word').text
                
                if wordCurrent == word:
                    #the current word is found
                    position_checker = True
                    node=graph.find('node_to').text
                    return node
    
    return False
def theNextNode(pathway,node):
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    counter=0
    for graph in root.findall(pathway):
        currentNode = graph.find('node').text
        
        if currentNode == node:
             #the current word is found
             nextnode=graph.find('node_to').text
             return nextnode
        counter+=1
    
    return False
def getPrevious(pathway,node):
    #get previous node
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    nodes=[]
    for graph in root.findall(pathway):
        nodeCurrent = graph.find('node_to').text#get the word
        if nodeCurrent == node:
                #Find the position of word
                nodes.append(graph.find('node').text)
    return nodes #returns the nodes
def getNode(pathway,word):
    #use the word to find the node current
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    for graph in root.findall(pathway):
        wordCurrent = graph.find('word').text#get the word
        if wordCurrent == word:
                #Find the position of word
                nodeCurrent = graph.find('node').text
                return nodeCurrent #returns the word at the node
def getWord(pathway,node):
    #get the word wanted
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    
    for graph in root.findall(pathway):
        nodeCurrent = graph.find('node').text#get the word
        if nodeCurrent == node:
                #Find the position of word
                wordCurrent = graph.find('word').text
                return wordCurrent #returns the word at the node
def visitedNode(pathway,node):
    #get the word wanted
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    wordCurrent=""
    for graph in root.findall(pathway):
        nodeCurrent = graph.find('node').text#get the word
        if nodeCurrent == node:
                #Find the position of word
                wordCurrent = graph.find('visited').text
                return wordCurrent #returns the word at the node
    if wordCurrent == "":
        return "1"
def writeNode(Type,position,word,node,nodeTo):
    #add a new node
    file = open("tree.xml","r")    #open database
    r = file.read() #read data
    file.close()
    r = r.replace("</data>","") #remove end
    r = r + "\t<"+Type+" num="+'"'+str(position)+"\">\n"
    r = r + "\t<word>"+word+"</word>\n"
    r = r + "\t<visited>"+visitedNode(Type,node)+"</visited>\n"
    r = r + "\t<node>"+str(node)+"</node>\n"
    r = r + "\t<node_to>"+str(nodeTo)+"</node_to>\n"
    r = r + "\t</"+Type+">\n"
    r = r + "\t</data>\n"
    file = open("tree.xml","w")    #open database
    file.write(r) #write to file
    file.close()
def getNodeNum(pathway):
    #count the nodes
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    
    counter=1
    for graph in root.findall(pathway):
        counter+=1
    return counter
def replaceNode(Type,position,word,node,nodeTo,visited):
    #replace old node
    file = open("tree.xml","r")    #open database
    r = file.read() #read data
    file.close()
    f=""
    g=""
    f = f + "\t<"+Type+" num="+'"'+str(position)+"\">\n"
    f = f + "\t<word>"+word+"</word>\n"
    f = f + "\t<visited>"+visitedNode(Type,node)+"</visited>\n"
    f = f + "\t<node>"+str(node)+"</node>\n"
    f = f + "\t<node_to>"+openNode(Type,position,word)+"</node_to>\n"
    f = f + "\t</"+Type+">\n"
    
    #print("f---"+"/n"+f)
    
    g = g + "\t<"+Type+" num="+'"'+str(position)+"\">\n"
    g = g + "\t<word>"+word+"</word>\n"
    g = g + "\t<visited>"+visited+"</visited>\n"
    g = g + "\t<node>"+str(node)+"</node>\n"
    g = g + "\t<node_to>"+str(nodeTo)+"</node_to>\n"
    g = g + "\t</"+Type+">\n"
    
    #print("g---"+"/n"+g)
    r = r.replace(f,g)
    file = open("tree.xml","w")    #open database
    file.write(r) #write to file
    file.close()
def traverseDepth(startNode):
    stack=[]#store each of nodes in
    nodesTo=[]#store nodes on each layer not used
    visited=[]#boolean if visited
    text=[]#store text phrases
    
    nextNode = startNode.replace("!S!","")
    notVisited=[]#store those not visited
    finished=False
    counter=0#counts size of arrays
    pointer=0#stack position
    #get the word wanted
    tree = ET.parse('tree.xml')
    root = tree.getroot()
    wordCurrent=""
    for graph in root.findall('answer'):
        nodeCurrent = graph.find('node').text#get the node
        
        visited.append(False)
        nodesTo.append(graph.find('node_to').text)#get the node to
        text.append(graph.find('word').text)#get the word
        
        
        
        
    print("Nodes|Visited|NodesTo|Text")
    print("--------------------------")
    for i in range(len(nodesTo)):
            
            print(i+1,"|",visited[i],"|",nodesTo[i],"|",text[i])
        
    
def getOutput(pos):
    #get the output of a node
    pos = pos.replace("!S!","")
    string=""
    nextNode=pos
    print("answers",nextNode)
    
    while nextNode!="!": #gather sentence till nothing more
        string+=getWord("answer",nextNode)+" "
        nextNode=theNextNode("answer",nextNode)
        
        
    if string=="": #nothing found
        return False
    return string
    
def find(Type,words):
    complete=False
    output=""
    firstFound=True #sets there is a found word
    while(complete == False):
        word=words.split()
        first = openNode(Type,1,word[0]) #get the first node
        
        if first:
            #if the word is there
            node=first
            if len(word) > 1: #more than one word
                oldNode=first
                for i in range(len(word)-1):
                    place = i+1
                    #none=theNextNode('path',node)
                    node=openNode(Type,place+1,word[place])
                    #check if the previous word existed
                    
                    if node:
                        #if it exists
                        
                        if firstFound==False:
                            
                            num=getNodeNum(Type)#get the amount there are
                            
                            #replace the old node with new node
                            finder=openNode(Type,place,word[place-1])
                            if finder != "!":
                                num=finder+","+str(num)
                            replaceNode(Type,place,word[place-1],getNode(Type,word[place-1]),getNode(Type,word[place]),visitedNode(Type,getNode(Type,word[place-1])))
                            firstFound=True #set back to how it should be
                        
                        if "!S!" in node and len(getPrevious('path',oldNode)) != len(node.split(",")):
                            #the final node
                            #must be checked if previous words match
                            tree = ET.parse('tree.xml')
                            root = tree.getroot()
                            
                            for graph in root.findall(Type):
                                nodeCurrent = graph.find('node_to').text#get the word
                                if nodeCurrent == node:
                                        #Find the position of word
                                        oldNode = graph.find('node').text
                            
                            previous=getPrevious('path',oldNode)
                            for i in range(len(previous)):
                                if getWord(Type,previous[i]) ==word[place-1]:
                                    #The word prior to this one has same node
                                    
                                    replaceNode(Type,place+1,word[place],getNode(Type,word[place]),node+",!",visitedNode(Type,getNode(Type,word[place])))
                        else:
                            nodes=node.split(",")
                            for j in range(len(nodes)):
                                if place+1<=len(word)-1:
                                    #there is room for more words
                                    if getWord(Type,nodes[j])==word[place+1]:
                                        node=nodes[j]
                                else:
                                    #there are no more words afterwards
                                    #add a solution
                                    x=0
                    else:
                        #it does not
                        
                        num=getNodeNum(Type)#get the amount there are
                        writeNode(Type,place+1,word[place],num,'!')
                        #replace the old node with new node
                        finder=openNode(Type,place,word[place-1])
                        visit=visitedNode(Type,getNode(Type,word[place-1]))
                        if finder != "!":
                            num=finder+","+str(num)
                            visit=str(int(visitedNode(Type,getNode(Type,word[place-1])))+1)
                        replaceNode(Type,place,word[place-1],getNode(Type,word[place-1]),num,visit) #the num (node to go to) increasess after one has been added
                    oldNode=node
            else: #one word sentence
                if first != '!':
                    #there is a reply
                    output=getOutput(node)
                #there is not a reply output will be ""
            complete=True
        else:
            #there is not a node
            writeNode(Type,1,word[0],getNodeNum(Type),'!')#write one
            firstFound=False #sets there is no found word
            
            
    if output != "":
        return output #return if output has been found
    else:
        return False
def search(Type,word):
    #do a search using nodes
    #will only work if everything is already written into the data
    reply=find(Type,word)
    words=word.split()
    node=getNode(Type,words[0]) #get the first node
    count=1
    counter=0
    for i in range(len(words)-1):
        count=1+i
        nodes=theNextNode(Type,node)
        
        nodes=nodes.split(",") #get every node
        
        for j in range(len(nodes)): #check every node
            if count <= len(words):
                if getWord(Type,nodes[j]) == words[count]: #check word is present
                    counter+=1
                    node=nodes[j]
                    
                    break #not needed but here for stopping future bugs
                   
    if counter == len(words)-1:
        if "!" in node.replace("!S!",""): #if there is an absents.
            original=node #save original
            node=node.replace("!S!","")
            node=node.split(",")#split down to list
            counter=0
            array=[]
            for j in range(len(words)):
                old=getPrevious(Type,original)
                for i in range(len(old)):
                    if getWord(Type,old[i])==words[len(words)-1-i]:
                        print("found")
                        counter+=1
                        array.append(old[i])
        string = getOutput(theNextNode(Type,node))
        return string #returns the saved
    else:
        return False
            
def show():
    file = open("tree.xml","r")    #open database
    r = file.read() #read data
    file.close()
    print(r)
def dele():
    file = open("tree.xml","w")
    file.write("<data>\n\n</data>")
    file.close()
exit = True
#dele()
while exit:        
    sentence=input(":")
    
    
    reply=search('path',sentence)
    #need to do a second search
    #show()
    print(reply)
    
    if reply!=False: #something is found
        print("Robot message: "+reply)
    else: #nothing within data to needs reply
        print("Robot message: I am not sure how to respond? How would you like me to.")
        reply=input() #get reply
        words=sentence.split()
        node=getNode('path',words[len(words)-1])#get final node
        thenext=theNextNode('path',node)
        reply=reply.split()
        counter=0
        if thenext =="!":
            for i in range(len(reply)-1):
                writeNode('answer',i+1,reply[i],getNodeNum('answer'),getNodeNum('answer')+1)
                counter=i+1
            #replaceNode('answer',len(reply),reply[len(reply)-1],getNodeNum('answer'),"!",1)
            writeNode('answer',counter+1,reply[len(reply)-1],getNodeNum('answer'),"!")

            nodeTo=str(int(getNodeNum('answer'))-len(reply))
            print(nodeTo,reply[0])
            replaceNode('path',len(words),words[len(words)-1],node,"!S!"+nodeTo,visitedNode("answer",node))
